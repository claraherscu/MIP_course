function showRegistrationResult ( tform )

    % get the pictures
    load brain.mat;
    transformedBrain = imwarp(brain_moving,tform, 'outputView', ...
        imref2d(size(brain_fixed)));
        
%     xCoordDif = size(transformedBrain,1) - size(brain_fixed,1);
%     yCoordDif = size(transformedBrain,2) - size(brain_fixed,2);
%     cropped_brain = transformedBrain(xCoordDif:xCoordDif + ...
%         size(brain_fixed,1), yCoordDif:yCoordDif + size(brain_fixed,2));
%     neededAlignment = [1 0 0; 0 1 0; -xCoordDif -yCoordDif 1];
%     alignedBrain = imwarp(transformedBrain, affine2d(neededAlignment));
    
    % show the pictures together
    figure;
    subplot(1,3,1);
    imshow(brain_fixed);
    title('Fixed brain');
    subplot(1,3,2);
    imshowpair(transformedBrain, brain_fixed);
    title('Comparison');
    subplot(1,3,3);
    imshow(transformedBrain);
    title('Transformation result');

%     N = size(movingPoints,1);
%     transformed_points = [movingPoints ones(N,1)] * rigidReg;
%     part1.showPointsOnPictures(brain_fixed, transformedBrain, fixedPoints,...
%         transformed_points);

end