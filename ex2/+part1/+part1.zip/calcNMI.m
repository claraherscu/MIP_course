function nmi = calcNMI ( A, B )
% CALCNMI calculate the NMI of A and B
%   NMI(A,B) = (H(A)+H(B))/H(A,B) -> using histcounts2

    [h_ab, ~, ~] = histcounts2(A,B);
    [h_a, ~] = histcounts(A);
    [h_b, ~] = histcounts(B);
    % doesn't work because dimentions are incompatible, it's written in the
    % targil description that i have to figure out a smart way to define
    % the limits and num of cells of the histograms
    nmi = (h_a + h_b)/h_ab;

end