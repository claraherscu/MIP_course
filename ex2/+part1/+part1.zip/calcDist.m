function d_pixel = calcDist(fixedPoints, movingPoints, rigidReg)
% CALCDIST calculate the Root Mean Square Error of the registration

    N = size(fixedPoints,1);
    transformedPoints = [movingPoints ones(N,1)] * rigidReg;
    squaredErrors = ([fixedPoints ones(N,1)] - transformedPoints) .^ 2;
    RMSE = sqrt(mean(squaredErrors));
    d_pixel = sum(RMSE);

end